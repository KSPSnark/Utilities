# GliderStats
An aid for building atmospheric gliders.

Measures statistics while in "gliding" flight, and displays them next to the navball. Tracked statistics include:

* Glide ratio
* Descent speed

Has configuration options for tweaking the behavior.
